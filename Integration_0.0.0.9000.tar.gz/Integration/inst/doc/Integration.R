## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
#library(Integration) # can't load as library yet
library(tidyverse)

## -----------------------------------------------------------------------------
resultRiemann <- Integration::riemann(100,sqrt,c(0,10))
resultTrapezoid <- Integration::trapezoid(100,sqrt,c(0,10))
resultSimpsons <- Integration::simpsons(100,sqrt,c(0,10))

paste("The approximate Riemann value is", resultRiemann)
paste("The approximate Trapezoidal value is", resultTrapezoid)
paste("The approximate Simpsons value is", resultSimpsons)

## -----------------------------------------------------------------------------
cubicFunction = function(x){
  result = x^3
}

## -----------------------------------------------------------------------------
resultRiemann <- Integration::riemann(100,cubicFunction,c(0,2))
resultTrapezoid <- Integration::trapezoid(100,cubicFunction,c(0,2))
resultSimpsons <- Integration::simpsons(100,cubicFunction,c(0,2))

paste("The approximate Riemann value is", resultRiemann)
paste("The approximate Trapezoidal value is", resultTrapezoid)
paste("The approximate Simpsons value is", resultSimpsons)

## -----------------------------------------------------------------------------
# load functionvalues
x = 0:20
f <- sqrt(x)
f <- data.frame(f = f, 
                   x = x)

# set params
a = 0
b = 10
nIntervals = 5

## -----------------------------------------------------------------------------
df1 <- tibble(x = unique(sort(c(seq(0,b,.01),20))),
                    f = sqrt(x))

df2 <- df1 %>%
  filter(x <= b & x>=a) %>%
  bind_rows(tibble(x = b, f = 0)) %>%
  bind_rows(tibble(x = a, f = 0)) 

finalFig <- df1 %>%
  ggplot(aes(x = x, y = f)) + 
  geom_line(colour = "red") +
  ylab("Density") + 
  geom_hline(yintercept = 0)+
  geom_polygon(data = df2, fill = "red", alpha = .5)+
  theme_minimal()+ 
  labs(title = "Target Area of Square Root Function", 
       subtitle = "Integrate from 0 to 10")

finalFig


## -----------------------------------------------------------------------------
dfRiemann = tibble(n = nIntervals, 
                   x = seq(a,b,length = nIntervals+1)[-(nIntervals+1)], 
                   f = sqrt(x))%>%
  mutate(x1 = x + (b-a)/(2*n))

finalFig+
  geom_bar(data = dfRiemann, aes(x=x1,y=f),stat = "identity",fill="darkblue",
           alpha=0.7,
           width = (b-a)/nIntervals)+
  theme_minimal()+ 
  labs(title = "Riemann Integration of Square Root Function", 
       subtitle = "Riemann Approximations in Blue")

## -----------------------------------------------------------------------------
resultRiemann <- Integration::riemann(nIntervals,sqrt,c(a,b))
paste("The approximate Riemann value with range (",a,",",b,")", "and",nIntervals,"intervals is", round(resultRiemann,3))

## -----------------------------------------------------------------------------
dfTrapezoid = tibble(n = nIntervals, 
                   x = seq(a,b,length = nIntervals+1), 
                   f = sqrt(x))%>%
  bind_rows(tibble(n = nIntervals, 
                   x = b-a,
                   f = 0))

finalFig+
  geom_polygon(data= dfTrapezoid, aes(x=x,y=f),fill="darkblue",alpha=0.7)+
  theme_minimal()+ 
  labs(title = "Trapezoidal Integration of Square Root Function", 
       subtitle = "Trapezoidal Approximations in Blue")

## -----------------------------------------------------------------------------
resultTrapezoid <- Integration::trapezoid(nIntervals,sqrt,c(a,b))
paste("The approximate Trapezoidal value with range (",a,",",b,")", "and",nIntervals,"intervals is", round(resultTrapezoid,3))

## -----------------------------------------------------------------------------
n = 1:100
dfSpeed = tibble(n =n)
dfSpeed$Riemann = sapply(dfSpeed$n, Integration::riemann, sqrt, c(a,b))
dfSpeed$Trapezoid = sapply(dfSpeed$n, Integration::trapezoid, sqrt, c(a,b))
dfSpeed$Simpsons = sapply(dfSpeed$n, Integration::simpsons, sqrt, c(a,b))

## -----------------------------------------------------------------------------
dfSpeedLong = dfSpeed %>%
  pivot_longer(cols = c("Riemann","Trapezoid","Simpsons"), names_to = "Algorithm", 
               values_to = "Values")

ggplot(dfSpeedLong)+ 
  geom_line(aes(x=n,y = Values, color = Algorithm))+ 
  theme_minimal()+ 
  labs(title = "Comparing Covergence of Integration Algorithms",
       subtitle = "Integrating the square root function from 0 to 10",
       x = "Number of Intervals",
       y = "Approximated Area Under the Curve")

